
var control

function inicioJuego(){
  var cuenta=120;
  var control = setInterval(function() {
    var minutos = parseInt((cuenta % (60 * 60)) / (60));
    var segundos = parseInt(cuenta % (60));
    $("#Timer").text( minutos + ": " + segundos);
    if (cuenta <= 0) {
      clearInterval(control);
      $(".panel-tablero").fadeOut(300, function(){ $(this).remove();});
      $(".time").fadeOut(300, function(){ $(this).remove();});
      $(".panel-score").animate(
        {width:1200},
        400,
        function () {
          $(".final").show();
        }
      )

    }
    cuenta =  cuenta - 1;
      }, 1000);
}
