var puntuacion=0;
var clicks=0;
var movimiento=0;
$(document).ready(function() {
function CambioColor() {
$(".main-titulo").animate({
color: "#fff",
}, 1000, function() {
RetornoColor();
})
}

function RetornoColor() {
$(".main-titulo").animate({
color: "#DCFF0E",
}, 1000, function() {
CambioColor();
})
}

CambioColor();


function dragAndDrop() {
  $(".elemento")
  .draggable({
      grid: [120, 90],
      revert: "valid"})
  .droppable({
    accept:".elemento",
    drop:function(event,ui){
      var actual= $(this).attr("src");
      var agarrado= $(ui.draggable).attr("src");

      $(this).attr("src", agarrado);
      $(ui.draggable).attr("src", actual);

      movimiento++;
      $("#movimientos-text").text(movimiento)
    }
  })
}

function CambiarReiniciar() {
clicks ++;
if(clicks==1){
    $(".btn-reinicio").text("reiniciar");
}else {
location.reload();
}

}


function llenarImagenes() {
  $("div[class^='col']").each(function(){
    for (var i = 1; i < 8; i++) {
      num=Math.floor((Math.random()*4)+1);
      $(this).append('<img class="elemento" src="image/' + num + '.png">');
}
});
}
  $('.btn-reinicio').click(function(){
    llenarImagenes();
    ValidarDulce();
    punto();
    checkSrc();
    comenzarjuego();
    inicioJuego();
    dragAndDrop();
    CambiarReiniciar();
  });


function rellenarTurno(){
var numeroElementos = numeroFalta = 0;
for (var i = 1; i <= 7; i++) {
numeroElementos=$(".col-"+i).find("img").length;
numeroFalta = 7 - numeroElementos;
llenarElemento($(".col-"+i), numeroFalta);
}
dragAndDrop();
window.setTimeout(comenzarjuego,1000)
}

function comenzarjuego(){
ValidarDulce();
window.setTimeout(eliminarElemento, 2100);
window.setTimeout(rellenarTurno, 2200);
}

function llenarElemento(elemento1,elemento2) {
  for (var i = 0; i < elemento2; i++) {
    num=Math.floor((Math.random()*4)+1);
    $(elemento1).prepend('<img class="elemento" src="image/' + num + '.png">');
  }
}
function eliminarElemento(){
  $("img:hidden").each(function(){
    $(this).remove();
  })
}


  function punto(elemento1, elemento2, elemento3){
  puntuacion= puntuacion + 10;
  $("#score-text").text(puntuacion);
  $(elemento1).hide('pulsate', 2000)
  $(elemento2).hide('pulsate', 2000)
  $(elemento3).hide('pulsate', 2000)

  }

  function checkSrc(elemento1, elemento2){
if ($(elemento1).attr("src")==$(elemento2).attr("src")) {
return true;
}else return false;

}

function ValidarDulce() {
  var comparacion;
  var actual;
  var parejaIzquierda=false;
  var parejaDerecha=false;
  var parejaArriba=false;
  var parejaAbajo=false;

  for (var col = 1; col < 8; col++) {
    for (var fila = 1; fila < 8; fila++) {
      parejaAbajo=parejaArriba=parejaIzquierda=parejaDerecha=false;
      actual=$(".col-"+col).find("img")[fila]

      if($(".col-"+(col-1)).length>0){
        comparacion=$(".col-"+(col-1)).find("img")[fila]
        if (checkSrc(actual,comparacion)) {
          parejaIzquierda=true;
          if ($(".col-"+(col-2)).length>0){
            comparacion=$(".col-"+(col-2)).find("img")[fila]
            if (checkSrc(actual,comparacion)) {
              punto(actual,$(".col-"+(col-1)).find("img")[fila],comparacion)
            }
          }
        }
      }
      if($(".col-"+(col+1)).length>0){
        comparacion=$(".col-"+(col+1)).find("img")[fila]
        if (checkSrc(actual,comparacion)) {
          parejaDerecha=true;
          if ($(".col-"+(col-2)).length>0){
            comparacion=$(".col-"+(col-2)).find("img")[fila]
            if (checkSrc(actual,comparacion)) {
              punto(actual,$(".col-"+(col+1)).find("img")[fila],comparacion)
}
}
}
 }
      if (parejaDerecha==true && parejaIzquierda==true) {
        punto(actual, $(".col-"+(col-1)).find("img")[fila], $(".col-"+(col+1)).find("img")[fila])

      }

  if($(".col-"+col).find("img")[fila-1]){
  comparacion = $(".col-"+col).find("img")[fila-1]
  if (checkSrc(actual, comparacion)) {
    parejaArriba = true;
    if($(".col-"+col).find("img")[fila-2]){
      comparacion = $(".col-"+col).find("img")[fila-2]
      if(checkSrc(actual, comparacion)){
        punto(actual, $(".col-"+col).find("img")[fila-1], comparacion)

      }
    }
  }
}
  if($(".col-"+col).find("img")[fila+1]){
    comparacion=$(".col-"+col).find("img")[fila+1]
    if (checkSrc(actual,comparacion)) {
      parejaAbajo=true;
      if ($(".col-"+col).find("img")[fila+2]) {
        comparacion=$(".col"+col).find("img")[fila+2]
        if (checkSrc(actual,comparacion)) {
          punto(actual,$(".col-"+col).find("img")[fila+1],comparacion)
        }
      }
    }
  }
if (parejaAbajo==true && parejaArriba==true) {
  punto(actual,$("col"+col).find("img")[fila+1],$("col"+col).find("img")[fila-1])
}
}
  }
}

})
